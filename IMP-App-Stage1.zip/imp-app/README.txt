IMP-App Etappe 1 (Root-App: Welcome-Tab; Moderation/Support = Platzhalter)
Voraussetzung: Node.js >= 22, Windows/macOS, Root-Konto mit Recht "Manage Apps" in der Community.
1. https://dev.rootapp.com -> My apps -> New app (Name "IMP") -> Create. App-ID kopieren.
2. App-ID in root-manifest.json bei "id" eintragen (ersetzt "your-app-id").
3. Im Developer Portal einen Token erzeugen; in server/.env eintragen: DEV_TOKEN=<token>
4. Im Projektordner: npm run setup   (= npm i + Netzwerkcode + Build; einmalig). Danach reicht: npm run build
5. Test lokal: Terminal A: cd server && npm run server   Terminal B: cd client && npm run client
   (DevBar oben im Browser = Mitglied wählen; Tab "Chat Moderation" erscheint nur für Staff.)
6. Paket: npx rootsdk build package  ->  .pkg-Datei
7. Hochladen: npx rootsdk upload package --file <datei.pkg> --authToken <token>
8. In Root als Mitglied mit "Manage Apps" die App installieren (Store/App-Verwaltung der Community).
   Beim Install den Picker "Staff-Rollen" ausfüllen (Owner ist immer Staff). Kanal: Jede App läuft in
   ihrem eigenen Kanal - diesen Kanal in Root in "Server" umbenennen bzw. dorthin verschieben.
Rechte (Manifest): keine Community-/Kanal-Rechte nötig (nur Events + Mitgliederliste lesen).
Willkommenstext ändern: server/src/welcome.config.json ("template", Platzhalter {member} {community}),
  danach npm run build und neu hochladen. Admin-Editor folgt in der Moderations-Etappe.
Daten: Beitrittsverlauf in SQLite (Root sichert automatisch), überlebt Neustarts. Tests: cd server && npm test
Vorschau mit Demo-Daten (ohne Root): cd client && npm run preview:build (Ausgabe dist-preview/).
Hinweis Online-Status: Root liefert ihn nur für Mitglieder, die die Community geöffnet haben (bzw. Freunde).
