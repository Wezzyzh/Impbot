// Einmal-Setup. Der Netzwerkcode (networking/gen) wird erst beim Build erzeugt und von npm als Kopie
// in node_modules eingebunden; deshalb: bauen -> alte Kopien löschen -> npm i, bis alles konsistent ist.
const { execSync } = require("child_process");
const fs = require("fs");
const run = (c) => execSync(c, { stdio: "inherit" });
const refresh = () => {
  for (const n of ["gen-client", "gen-server", "gen-shared"]) fs.rmSync("node_modules/@imp/" + n, { recursive: true, force: true });
  run("npm i");
};
run("npm i");
for (let i = 0; i < 2; i++) {
  try { run("npm run build -w networking"); } catch { console.log("(Netzwerk-Build unvollständig - Wiederholung)"); }
  refresh();
}
run("npm run build");
