import config from "./welcome.config.json";

export const MAX_WELCOME_LENGTH = 500;

export interface WelcomeVars {
  member: string;
  community: string;
}

/** Ersetzt {member} und {community} (einmaliger Durchlauf: Namen mit Platzhaltern werden nicht erneut ersetzt). */
export function renderWelcome(template: string, vars: WelcomeVars): string {
  const out = template.replace(/\{(member|community)\}/gi, (_m, key: string) =>
    key.toLowerCase() === "member" ? vars.member : vars.community,
  );
  return out.length > MAX_WELCOME_LENGTH ? out.slice(0, MAX_WELCOME_LENGTH - 1) + "…" : out;
}

/** Standardtext aus welcome.config.json. (Etappe 2: Admin-Editor ersetzt diese Quelle.) */
export function getWelcomeTemplate(): string {
  const t = (config as { template?: unknown }).template;
  return typeof t === "string" && t.trim() ? t : "Willkommen {member} in {community}!";
}
