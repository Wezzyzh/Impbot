export interface StaffGroup {
  isMember(req: { userId: string }): Promise<boolean>;
}

export interface AccessDeps {
  getOwnerUserId(): Promise<string>;
  /** Manifest-Setting general.staffRoles (kann fehlen, solange nicht konfiguriert). */
  getStaffGroup(): StaffGroup | undefined;
}

export interface Access {
  isOwner: boolean;
  isStaff: boolean;
}

export class NotStaffError extends Error {
  constructor() {
    super("Nur für Staff");
    this.name = "NotStaffError";
  }
}

/** Owner ist immer Staff; sonst Mitglied der konfigurierten Staff-Rollen/-Nutzer. Fail-closed bei Fehlern. */
export async function resolveAccess(deps: AccessDeps, userId: string): Promise<Access> {
  try {
    const isOwner = (await deps.getOwnerUserId()) === userId;
    if (isOwner) return { isOwner, isStaff: true };
    const group = deps.getStaffGroup();
    return { isOwner, isStaff: group ? await group.isMember({ userId }) : false };
  } catch {
    return { isOwner: false, isStaff: false };
  }
}

/** Für künftige Staff-only-RPCs: jede privilegierte Aktion muss serverseitig dies aufrufen. */
export async function assertStaff(deps: AccessDeps, userId: string): Promise<void> {
  if (!(await resolveAccess(deps, userId)).isStaff) throw new NotStaffError();
}
