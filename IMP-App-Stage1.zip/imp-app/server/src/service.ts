import {
  Client,
  rootServer,
  ReadOnlyMemberGroup,
  RootGuidUtils,
  RootGuidType,
} from "@rootsdk/server-app";
import { ImpServiceBase } from "@imp/gen-server";
import {
  ViewerContextRequest, ViewerContextResponse,
  MemberIdsRequest, MemberIdsResponse,
  ListJoinsRequest, ListJoinsResponse,
} from "@imp/gen-shared";
import { AccessDeps, resolveAccess } from "./access";
import { JoinStore } from "./store";
import { getWelcomeTemplate } from "./welcome";

export const accessDeps: AccessDeps = {
  getOwnerUserId: async () => (await rootServer.community.communities.get()).ownerUserId,
  getStaffGroup: () =>
    rootServer.globalSettings?.general?.staffRoles as ReadOnlyMemberGroup | undefined,
};

const MAX_IDS_PER_PAGE = 500;
const ID_CACHE_MS = 3000;

export class ImpService extends ImpServiceBase {
  private idCache: { at: number; ids: string[] } | undefined;
  constructor(private readonly store: JoinStore) { super(); }

  /** Nur Personen (keine Apps/Bots), stabil sortiert. */
  private async personIds(): Promise<string[]> {
    if (this.idCache && Date.now() - this.idCache.at < ID_CACHE_MS) return this.idCache.ids;
    const all = await rootServer.community.communityMembers.listAll();
    const ids = all
      .filter((m) => RootGuidUtils.toRootGuidType(m.userId) === RootGuidType.Person)
      .map((m) => m.userId as string)
      .sort();
    this.idCache = { at: Date.now(), ids };
    return ids;
  }

  async getViewerContext(_req: ViewerContextRequest, client: Client): Promise<ViewerContextResponse> {
    const access = await resolveAccess(accessDeps, client.userId);
    const community = await rootServer.community.communities.get();
    return { userId: client.userId, isStaff: access.isStaff, isOwner: access.isOwner, communityName: community.name, welcomeTemplate: getWelcomeTemplate() };
  }

  async listMemberIds(req: MemberIdsRequest, _client: Client): Promise<MemberIdsResponse> {
    const ids = await this.personIds();
    const limit = Math.min(req.limit || MAX_IDS_PER_PAGE, MAX_IDS_PER_PAGE);
    return { total: ids.length, userIds: ids.slice(req.offset, req.offset + limit) };
  }

  async listJoins(req: ListJoinsRequest, _client: Client): Promise<ListJoinsResponse> {
    const page = await this.store.list(req.limit, req.cursor);
    return {
      entries: page.entries.map((e) => ({
        id: BigInt(e.id), userId: e.userId, nickname: e.nickname, avatarUri: e.avatarUri,
        joinedAt: BigInt(e.joinedAt), welcomeText: e.welcomeText,
      })),
      nextCursor: page.nextCursor,
      total: BigInt(page.total),
    };
  }
}
