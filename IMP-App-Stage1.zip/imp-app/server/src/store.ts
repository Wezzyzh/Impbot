import sqlite3 from "sqlite3";

export interface JoinRecord {
  id: number;
  userId: string;
  nickname: string;
  avatarUri: string;
  joinedAt: number; // Unix-ms
  welcomeText: string;
}
export type NewJoin = Omit<JoinRecord, "id">;
export interface JoinPage {
  entries: JoinRecord[];
  nextCursor: string; // "" = Ende
  total: number;
}

export const DEFAULT_PAGE = 25;
export const MAX_PAGE = 100;

interface Row {
  id: number; user_id: string; nickname: string; avatar_uri: string; joined_at: number; welcome_text: string;
}

export class JoinStore {
  private constructor(private readonly db: sqlite3.Database) {}

  static async open(filename: string): Promise<JoinStore> {
    const db = await new Promise<sqlite3.Database>((resolve, reject) => {
      const d = new sqlite3.Database(filename, (err) => (err ? reject(err) : resolve(d)));
    });
    const store = new JoinStore(db);
    await store.run(
      `CREATE TABLE IF NOT EXISTS joins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        nickname TEXT NOT NULL,
        avatar_uri TEXT NOT NULL DEFAULT '',
        joined_at INTEGER NOT NULL,
        welcome_text TEXT NOT NULL
      )`,
    );
    return store;
  }

  private run(sql: string, params: unknown[] = []): Promise<{ lastID: number }> {
    return new Promise((resolve, reject) =>
      this.db.run(sql, params, function (this: sqlite3.RunResult, err) {
        err ? reject(err) : resolve({ lastID: this.lastID });
      }),
    );
  }
  private all<T>(sql: string, params: unknown[] = []): Promise<T[]> {
    return new Promise((resolve, reject) =>
      this.db.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows as T[]))),
    );
  }

  async add(j: NewJoin): Promise<JoinRecord> {
    const { lastID } = await this.run(
      "INSERT INTO joins (user_id, nickname, avatar_uri, joined_at, welcome_text) VALUES (?,?,?,?,?)",
      [j.userId, j.nickname, j.avatarUri, j.joinedAt, j.welcomeText],
    );
    return { id: lastID, ...j };
  }

  async count(): Promise<number> {
    const r = await this.all<{ c: number }>("SELECT COUNT(*) AS c FROM joins");
    return r[0]?.c ?? 0;
  }

  /** Neueste zuerst, Cursor-Pagination über die id (stabil auch bei neuen Einträgen während des Scrollens). */
  async list(limit: number = DEFAULT_PAGE, cursor: string = ""): Promise<JoinPage> {
    const lim = Math.min(Math.max(Math.floor(Number(limit)) || DEFAULT_PAGE, 1), MAX_PAGE);
    const cur = /^\d+$/.test(cursor) ? Number(cursor) : Number.MAX_SAFE_INTEGER;
    const rows = await this.all<Row>(
      "SELECT * FROM joins WHERE id < ? ORDER BY id DESC LIMIT ?",
      [cur, lim + 1],
    );
    const page = rows.slice(0, lim).map<JoinRecord>((r) => ({
      id: r.id, userId: r.user_id, nickname: r.nickname, avatarUri: r.avatar_uri,
      joinedAt: r.joined_at, welcomeText: r.welcome_text,
    }));
    return {
      entries: page,
      nextCursor: rows.length > lim && page.length ? String(page[page.length - 1].id) : "",
      total: await this.count(),
    };
  }

  close(): Promise<void> {
    return new Promise((resolve, reject) => this.db.close((e) => (e ? reject(e) : resolve())));
  }
}
