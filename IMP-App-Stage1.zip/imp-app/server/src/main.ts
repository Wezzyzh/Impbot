import {
  rootServer,
  RootAppStartState,
  RootGuidUtils,
  RootGuidType,
  CommunityEvent,
  CommunityJoinedEvent,
  CommunityMemberEvent,
  CommunityMemberRoleEvent,
  GlobalSettingsEvent,
} from "@rootsdk/server-app";
import { JoinStore } from "./store";
import { ImpService } from "./service";
import { getWelcomeTemplate, renderWelcome } from "./welcome";

let store: JoinStore;
let service: ImpService;
let statsTimer: ReturnType<typeof setTimeout> | undefined;

/** Gebündeltes Signal "Statistik/Rechte geändert" (Clients laden neu). */
function signalChanged(): void {
  if (statsTimer) return;
  statsTimer = setTimeout(() => {
    statsTimer = undefined;
    service.broadcastStatsChanged({}, "all");
  }, 800);
}

async function onJoined(evt: CommunityJoinedEvent): Promise<void> {
  try {
    if (RootGuidUtils.toRootGuidType(evt.userId) !== RootGuidType.Person) return;
    const [member, community] = await Promise.all([
      rootServer.community.communityMembers.get({ userId: evt.userId }),
      rootServer.community.communities.get(),
    ]);
    const record = await store.add({
      userId: evt.userId,
      nickname: member.nickname,
      avatarUri: member.profilePictureAssetUri ?? "",
      joinedAt: Date.now(),
      welcomeText: renderWelcome(getWelcomeTemplate(), { member: member.nickname, community: community.name }),
    });
    service.broadcastJoinAdded(
      {
        id: BigInt(record.id), userId: record.userId, nickname: record.nickname,
        avatarUri: record.avatarUri, joinedAt: BigInt(record.joinedAt), welcomeText: record.welcomeText,
      },
      "all",
    );
  } catch (err) {
    console.error("IMP: Beitritt konnte nicht gespeichert werden", err);
  }
  signalChanged();
}

async function onStarting(state: RootAppStartState): Promise<void> {
  store = await JoinStore.open(rootServer.dataStore.config.sqlite3!.filename);
  service = new ImpService(store);
  rootServer.lifecycle.addService(service);

  const { communities, communityMembers, communityMemberRoles } = rootServer.community;
  communities.on(CommunityEvent.CommunityJoined, onJoined);
  communities.on(CommunityEvent.CommunityLeave, signalChanged);
  communityMembers.on(CommunityMemberEvent.CommunityMemberAttach, signalChanged);
  communityMembers.on(CommunityMemberEvent.CommunityMemberDetach, signalChanged);
  // Staff-Rechte können sich ändern -> Clients laden Kontext neu
  state.globalSettings?.on(GlobalSettingsEvent.Update, signalChanged);
  communityMemberRoles.on(CommunityMemberRoleEvent.CommunityMemberRoleCreated, signalChanged);
  communityMemberRoles.on(CommunityMemberRoleEvent.CommunityMemberRoleDeleted, signalChanged);
}

(async () => {
  await rootServer.lifecycle.start(onStarting);
})();
