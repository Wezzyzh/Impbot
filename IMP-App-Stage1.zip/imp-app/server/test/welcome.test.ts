import test from "node:test";
import assert from "node:assert/strict";
import { renderWelcome, getWelcomeTemplate, MAX_WELCOME_LENGTH } from "../src/welcome";

test("ersetzt {member} und {community}, auch mehrfach und case-insensitiv", () => {
  assert.equal(
    renderWelcome("Hi {member}, willkommen in {Community}! {MEMBER}!", { member: "Luca", community: "Server" }),
    "Hi Luca, willkommen in Server! Luca!",
  );
});
test("kein erneutes Ersetzen in Namen und keine $-Sonderfälle", () => {
  assert.equal(renderWelcome("{member}", { member: "{community}$&", community: "X" }), "{community}$&");
});
test("Text ohne Platzhalter bleibt unverändert; Länge begrenzt", () => {
  assert.equal(renderWelcome("Hallo", { member: "a", community: "b" }), "Hallo");
  assert.equal(renderWelcome("x".repeat(900), { member: "a", community: "b" }).length, MAX_WELCOME_LENGTH);
});
test("Standardtext aus Konfig enthält beide Platzhalter", () => {
  const t = getWelcomeTemplate();
  assert.ok(t.includes("{member}") && t.includes("{community}"));
});
