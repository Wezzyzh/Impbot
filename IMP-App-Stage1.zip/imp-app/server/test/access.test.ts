import test from "node:test";
import assert from "node:assert/strict";
import { resolveAccess, assertStaff, NotStaffError, AccessDeps } from "../src/access";

const deps = (owner: string, staff?: string[], boom = false): AccessDeps => ({
  getOwnerUserId: async () => { if (boom) throw new Error("x"); return owner; },
  getStaffGroup: () => (staff ? { isMember: async ({ userId }) => staff.includes(userId) } : undefined),
});

test("Owner ist immer Staff, auch ohne Staff-Setting", async () => {
  assert.deepEqual(await resolveAccess(deps("o"), "o"), { isOwner: true, isStaff: true });
});
test("Staff-Mitglied ja, normales Mitglied nein", async () => {
  const d = deps("o", ["s"]);
  assert.deepEqual(await resolveAccess(d, "s"), { isOwner: false, isStaff: true });
  assert.deepEqual(await resolveAccess(d, "m"), { isOwner: false, isStaff: false });
});
test("Ohne Staff-Setting ist niemand außer Owner Staff", async () => {
  assert.equal((await resolveAccess(deps("o"), "s")).isStaff, false);
});
test("Fehler => fail-closed", async () => {
  assert.deepEqual(await resolveAccess(deps("o", ["s"], true), "s"), { isOwner: false, isStaff: false });
});
test("assertStaff wirft NotStaffError für Nicht-Staff", async () => {
  await assert.rejects(assertStaff(deps("o", ["s"]), "m"), NotStaffError);
  await assertStaff(deps("o", ["s"]), "s");
});
