import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { JoinStore } from "../src/store";

const mk = (i: number) => ({
  userId: `u${i}`, nickname: `Nick${i}`, avatarUri: i % 2 ? `asset://${i}` : "",
  joinedAt: 1_700_000_000_000 + i * 1000, welcomeText: `Willkommen Nick${i}`,
});

test("Einträge überleben Neustart (Datei wieder öffnen)", async () => {
  const dir = mkdtempSync(join(tmpdir(), "imp-"));
  const file = join(dir, "t.db");
  try {
    const a = await JoinStore.open(file);
    await a.add(mk(1));
    await a.add(mk(2));
    await a.close();
    const b = await JoinStore.open(file);
    const page = await b.list();
    assert.equal(page.total, 2);
    assert.deepEqual(page.entries.map((e) => e.nickname), ["Nick2", "Nick1"]);
    assert.equal(page.entries[1].avatarUri, "asset://1");
    await b.close();
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test("Pagination: neueste zuerst, lückenlos, nextCursor leer am Ende", async () => {
  const s = await JoinStore.open(":memory:");
  for (let i = 1; i <= 7; i++) await s.add(mk(i));
  const seen: string[] = [];
  let cursor = "", pages = 0;
  do {
    const p = await s.list(3, cursor);
    seen.push(...p.entries.map((e) => e.userId));
    cursor = p.nextCursor; pages++;
  } while (cursor);
  assert.deepEqual(seen, ["u7", "u6", "u5", "u4", "u3", "u2", "u1"]);
  assert.equal(pages, 3);
  const exact = await s.list(7);
  assert.equal(exact.nextCursor, "");
  await s.close();
});

test("Cursor bleibt stabil, wenn während des Scrollens neue Beitritte kommen", async () => {
  const s = await JoinStore.open(":memory:");
  for (let i = 1; i <= 4; i++) await s.add(mk(i));
  const p1 = await s.list(2);
  await s.add(mk(5));
  const p2 = await s.list(2, p1.nextCursor);
  assert.deepEqual(p2.entries.map((e) => e.userId), ["u2", "u1"]);
  await s.close();
});

test("Limit wird begrenzt; ungültiger Cursor = Anfang; leere DB", async () => {
  const s = await JoinStore.open(":memory:");
  assert.deepEqual(await s.list(), { entries: [], nextCursor: "", total: 0 });
  for (let i = 1; i <= 150; i++) await s.add(mk(i));
  assert.equal((await s.list(9999)).entries.length, 100);
  assert.equal((await s.list(0, "abc")).entries.length, 25);
  await s.close();
});
