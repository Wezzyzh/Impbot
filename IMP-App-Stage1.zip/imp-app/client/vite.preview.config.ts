import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";

// Vorschau-Build mit Demo-Daten (ohne Root). Aufruf: npm run preview:build
export default defineConfig({
  root: __dirname,
  base: "./",
  build: { outDir: "dist-preview", assetsInlineLimit: 100000 },
  resolve: {
    alias: {
      "@rootsdk/client-app": path.resolve(__dirname, "preview/mock-root-client.ts"),
      "@imp/gen-client": path.resolve(__dirname, "preview/mock-gen-client.ts"),
    },
  },
  plugins: [react()],
});
