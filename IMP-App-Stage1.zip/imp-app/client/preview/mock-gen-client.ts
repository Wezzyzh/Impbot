// NUR VORSCHAU (Demo-Daten). Gleiche Schnittstelle wie @imp/gen-client.
import { demoIds } from "./mock-root-client";
export enum ImpServiceClientEvent { JoinAdded = "broadcastJoinAdded", StatsChanged = "broadcastStatsChanged" }

const names = ["NovaStrike", "LunaByte", "PixelFox", "Kai_77", "ZenithGG", "MiraVolt", "Orion", "Sakura", "DaBoss", "Jules"];
const texts = (n: string) => `Willkommen ${n} in IMP Squad! Schön, dass du da bist. Lies dir kurz die Regeln durch und sag gern Hallo.`;
const now = Date.now();
const all = Array.from({ length: 60 }, (_, i) => {
  const n = names[i % names.length] + (i >= 10 ? i : "");
  return { id: BigInt(60 - i), userId: `u${i}`, nickname: n, avatarUri: i % 4 === 3 ? "" : `asset://${i}`, joinedAt: BigInt(now - i * 3_700_000 - 120_000), welcomeText: texts(n) };
});
const staff = new URLSearchParams(location.search).get("staff") === "1";

export const impServiceClient = {
  getViewerContext: async () => ({ userId: "me", isStaff: staff, isOwner: staff, communityName: "IMP Squad", welcomeTemplate: "Willkommen {member} in {community}! Schön, dass du da bist. Lies dir kurz die Regeln durch und sag gern Hallo." }),
  listMemberIds: async (r: { offset: number; limit: number }) => ({ total: demoIds.length, userIds: demoIds.slice(r.offset, r.offset + r.limit) }),
  listJoins: async (r: { limit: number; cursor: string }) => {
    const start = r.cursor ? all.findIndex((e) => String(e.id) === r.cursor) + 1 : 0;
    const entries = all.slice(start, start + r.limit);
    return { entries, nextCursor: start + r.limit < all.length ? String(entries[entries.length - 1].id) : "", total: BigInt(all.length) };
  },
  on: () => {}, off: () => {},
};
