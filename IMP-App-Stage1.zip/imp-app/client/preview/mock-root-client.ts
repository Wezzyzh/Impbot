// NUR VORSCHAU (Demo-Daten, kein Root-Zugriff). Wird nur von vite.preview.config.ts eingebunden.
export enum CommunityUserOnlineStatus { Unspecified = 0, OnlineAndAttached = 1, AwayAndAttached = 2, Online = 3, Away = 4, Offline = 5 }
export enum ImageUriResolution { Large = "large", Medium = "medium", Original = "original", Small = "small" }
export enum RootClientUserEvent { UserProfileUpdate = "user.profile.update" }

const hues = [265, 190, 300, 215, 330, 160];
const svg = (i: number) => "data:image/svg+xml;utf8," + encodeURIComponent(
  `<svg xmlns='http://www.w3.org/2000/svg' width='88' height='88'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='hsl(${hues[i % 6]},85%,62%)'/><stop offset='1' stop-color='hsl(${hues[(i + 2) % 6]},80%,40%)'/></linearGradient></defs><rect width='88' height='88' fill='url(#g)'/><circle cx='44' cy='34' r='15' fill='white' opacity='.9'/><path d='M14 88c4-24 20-30 30-30s26 6 30 30z' fill='white' opacity='.9'/></svg>`);

export const demoIds = Array.from({ length: 142 }, (_, i) => `u${i}`);
const status = (i: number) => (i % 5 === 0 ? CommunityUserOnlineStatus.OnlineAndAttached : i % 7 === 0 ? CommunityUserOnlineStatus.AwayAndAttached : CommunityUserOnlineStatus.Offline);

export const rootClient = {
  users: {
    getUserProfiles: async (ids: string[]) => ids.map((id) => ({ id, nickname: "", onlineStatus: status(Number(id.slice(1))) })).map((p) => ({ ...p, nickname: undefined as unknown as string })),
    on: () => {}, off: () => {},
  },
  assets: { toImageUrl: (uri: string) => (uri ? svg(Number(uri.replace(/\D/g, "")) || 0) : "") },
};
