import React, { useEffect, useRef, useState } from "react";
import { rootClient, ImageUriResolution } from "@rootsdk/client-app";
import type { ViewerContextResponse } from "@imp/gen-shared";
import { A } from "./assets";
import { useJoins, useStats } from "./hooks";
import type { JoinView } from "./hooks";
import { formatDate, formatTime } from "./presence";

function useCountUp(target: number | null): number | null {
  const [v, setV] = useState<number | null>(target);
  const from = useRef(0);
  useEffect(() => {
    if (target === null) { setV(null); return; }
    const start = from.current, t0 = performance.now(), dur = 600;
    let raf = 0;
    const step = (t: number) => {
      const k = Math.min((t - t0) / dur, 1), e = 1 - Math.pow(1 - k, 3);
      const val = Math.round(start + (target - start) * e);
      setV(val); from.current = val;
      if (k < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target]);
  return v;
}

const StatCard: React.FC<{ icon: string; label: string; value: number | null; tone?: "cyan" | "violet"; live?: boolean }> =
  ({ icon, label, value, tone = "violet", live }) => {
    const shown = useCountUp(value);
    return (
      <div className={`panel stat stat--${tone}`}>
        <div className="tile"><img src={icon} alt="" width={48} height={48} /></div>
        <div>
          <div className="stat__label">{live && <span className="pulse" />}{label}</div>
          <div className="stat__value">{shown === null ? "–" : shown.toLocaleString("de-CH")}</div>
        </div>
      </div>
    );
  };

const Avatar: React.FC<{ uri: string; name: string }> = ({ uri, name }) => {
  const [broken, setBroken] = useState(false);
  const url = uri ? rootClient.assets.toImageUrl(uri, ImageUriResolution.Small) : "";
  if (!url || broken) return <div className="avatar avatar--fallback" aria-hidden="true">{(name.trim()[0] ?? "?").toUpperCase()}</div>;
  return <img className="avatar" src={url} alt="" width={44} height={44} onError={() => setBroken(true)} />;
};

const JoinRow: React.FC<{ e: JoinView }> = ({ e }) => (
  <li className="join">
    <Avatar uri={e.avatarUri} name={e.nickname} />
    <div className="join__body">
      <div className="join__head">
        <span className="join__name">{e.nickname}</span>
        <span className="join__time"><span>{formatDate(e.joinedAt)}</span><i>·</i><span>{formatTime(e.joinedAt)} Uhr</span></span>
      </div>
      <p className="join__text">{e.welcomeText}</p>
    </div>
  </li>
);

export const Welcome: React.FC<{ viewer?: ViewerContextResponse }> = ({ viewer }) => {
  const { stats, error } = useStats();
  const joins = useJoins();
  const sentinel = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = sentinel.current;
    if (!el || !("IntersectionObserver" in window)) return;
    const io = new IntersectionObserver((en) => { if (en[0].isIntersecting && joins.items.length > 0) joins.loadMore(); }, { rootMargin: "240px" });
    io.observe(el);
    return () => io.disconnect();
  }, [joins.loadMore, joins.items.length]);

  const previewName = "Neues Mitglied";
  const preview = viewer?.welcomeTemplate
    ? viewer.welcomeTemplate.replace(/\{member\}/gi, previewName).replace(/\{community\}/gi, viewer.communityName || "Community")
    : "";

  return (
    <div className="stack">
      <section className="hero panel">
        <img className="hero__banner" src={A.banner} alt="IMP – Welcome to the squad" />
        <div className="hero__shade" />
      </section>

      <section className="stats" aria-label="Statistik">
        <StatCard icon={A.members} label="Mitglieder gesamt" value={stats ? stats.total : null} />
        {stats?.online != null && <StatCard icon={A.online} label="Online" value={stats.online} tone="cyan" live />}
        {stats?.offline != null && <StatCard icon={A.offline} label="Offline" value={stats.offline} />}
      </section>
      {error && <p className="note note--warn">Statistik konnte nicht geladen werden – neuer Versuch folgt automatisch.</p>}

      {preview && (
        <section className="panel msg">
          <div className="tile tile--sm"><img src={A.announce} alt="" width={32} height={32} /></div>
          <div>
            <h2 className="h2">Willkommensnachricht</h2>
            <p className="msg__text">{preview}</p>
            <p className="note">Platzhalter: <code>{"{member}"}</code> = Name des Mitglieds, <code>{"{community}"}</code> = Name der Community.</p>
          </div>
        </section>
      )}

      <section className="panel history">
        <header className="history__head">
          <div className="tile tile--sm"><img src={A.history} alt="" width={32} height={32} /></div>
          <h2 className="h2">Beitrittsverlauf</h2>
        </header>
        {joins.items.length === 0 && !joins.loading && !joins.failed && (
          <div className="empty">
            <img src={A.smile} alt="" width={56} height={56} />
            <p>Noch keine Beitritte aufgezeichnet.<br />Neue Mitglieder erscheinen hier automatisch.</p>
          </div>
        )}
        <ul className="joins">{joins.items.map((e) => <JoinRow key={e.id} e={e} />)}</ul>
        <div ref={sentinel} />
        {joins.failed && <p className="note note--warn">Verlauf konnte nicht geladen werden.</p>}
        {!joins.done && joins.items.length > 0 && (
          <button className="more" onClick={joins.loadMore} disabled={joins.loading}>{joins.loading ? "Lädt …" : "Mehr laden"}</button>
        )}
      </section>
    </div>
  );
};
