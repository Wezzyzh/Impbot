import members from "./assets/members.webp";
import online from "./assets/online.webp";
import offline from "./assets/offline.webp";
import history from "./assets/history.webp";
import announce from "./assets/announce.webp";
import welcome from "./assets/welcome.webp";
import shield from "./assets/shield.webp";
import support from "./assets/support.webp";
import logo from "./assets/logo.webp";
import smile from "./assets/smile.webp";
import banner from "./assets/banner.webp";

export const A = { members, online, offline, history, announce, welcome, shield, support, logo, smile, banner };
