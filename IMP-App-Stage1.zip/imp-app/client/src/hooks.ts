import { useCallback, useEffect, useRef, useState } from "react";
import { rootClient, RootClientUserEvent, CommunityUserOnlineStatus } from "@rootsdk/client-app";
import type { UserProfile } from "@rootsdk/client-app";
import { impServiceClient, ImpServiceClientEvent } from "@imp/gen-client";
import type { JoinEntry, ViewerContextResponse } from "@imp/gen-shared";
import { chunk, isOnline } from "./presence";

const FALLBACK_REFRESH_MS = 60_000;
const PAGE = 25;

export function useViewer() {
  const [viewer, setViewer] = useState<ViewerContextResponse | undefined>();
  const load = useCallback(async () => {
    try { setViewer(await impServiceClient.getViewerContext({})); }
    catch { setViewer(undefined); } // fail-closed: ohne Kontext kein Staff-Tab
  }, []);
  useEffect(() => {
    load();
    impServiceClient.on(ImpServiceClientEvent.StatsChanged, load);
    return () => { impServiceClient.off(ImpServiceClientEvent.StatsChanged, load); };
  }, [load]);
  return viewer;
}

export interface Stats { total: number; online: number | null; offline: number | null; }

/** Echte Root-Daten: Gesamtzahl vom Server, Online-Status aus rootClient.users (UserProfile.onlineStatus). */
export function useStats() {
  const [stats, setStats] = useState<Stats | undefined>();
  const [error, setError] = useState(false);
  const statuses = useRef(new Map<string, CommunityUserOnlineStatus>());
  const total = useRef(0);
  const seq = useRef(0);

  const recompute = useCallback(() => {
    const vals = [...statuses.current.values()];
    const known = vals.some((s) => s !== CommunityUserOnlineStatus.Unspecified);
    if (!known) { setStats({ total: total.current, online: null, offline: null }); return; }
    const online = vals.filter(isOnline).length;
    setStats({ total: total.current, online, offline: Math.max(total.current - online, 0) });
  }, []);

  const refresh = useCallback(async () => {
    const my = ++seq.current;
    try {
      const ids: string[] = [];
      let t = 0;
      do {
        const r = await impServiceClient.listMemberIds({ offset: ids.length, limit: 500 });
        t = r.total; ids.push(...r.userIds);
        if (r.userIds.length === 0) break;
      } while (ids.length < t);
      const map = new Map<string, CommunityUserOnlineStatus>();
      try {
        for (const part of chunk(ids, 200)) {
          for (const p of await rootClient.users.getUserProfiles(part)) map.set(p.id, p.onlineStatus);
        }
      } catch { map.clear(); } // Online-Status nicht verfügbar -> Karten ausblenden
      if (my !== seq.current) return;
      total.current = t; statuses.current = map; setError(false); recompute();
    } catch { if (my === seq.current) setError(true); }
  }, [recompute]);

  useEffect(() => {
    refresh();
    let timer: ReturnType<typeof setTimeout> | undefined;
    const debounced = () => { clearTimeout(timer); timer = setTimeout(refresh, 1200); };
    const onProfile = (p: UserProfile) => {
      if (statuses.current.has(p.id)) { statuses.current.set(p.id, p.onlineStatus); recompute(); }
    };
    impServiceClient.on(ImpServiceClientEvent.StatsChanged, debounced);
    rootClient.users.on(RootClientUserEvent.UserProfileUpdate, onProfile);
    const iv = setInterval(refresh, FALLBACK_REFRESH_MS);
    return () => {
      clearTimeout(timer); clearInterval(iv);
      impServiceClient.off(ImpServiceClientEvent.StatsChanged, debounced);
      rootClient.users.off(RootClientUserEvent.UserProfileUpdate, onProfile);
    };
  }, [refresh, recompute]);

  return { stats, error };
}

export interface JoinView {
  id: number; userId: string; nickname: string; avatarUri: string; joinedAt: number; welcomeText: string;
}
const toView = (e: JoinEntry): JoinView => ({
  id: Number(e.id), userId: e.userId, nickname: e.nickname, avatarUri: e.avatarUri,
  joinedAt: Number(e.joinedAt), welcomeText: e.welcomeText,
});

/** Beitrittsverlauf mit Cursor-Pagination; neue Beitritte erscheinen live oben. */
export function useJoins() {
  const [items, setItems] = useState<JoinView[]>([]);
  const [cursor, setCursor] = useState("");
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);
  const [failed, setFailed] = useState(false);
  const busy = useRef(false);
  const cur = useRef({ cursor: "", done: false });

  const loadMore = useCallback(async () => {
    if (busy.current || cur.current.done) return;
    busy.current = true; setLoading(true);
    try {
      const r = await impServiceClient.listJoins({ limit: PAGE, cursor: cur.current.cursor });
      const views = r.entries.map(toView);
      // Aktuelle Profile (Name/Avatar) überlagern den Snapshot; ehemalige Mitglieder behalten den Snapshot.
      try {
        const profiles = await rootClient.users.getUserProfiles([...new Set(views.map((v) => v.userId))]);
        const byId = new Map(profiles.map((p) => [p.id, p]));
        for (const v of views) {
          const p = byId.get(v.userId);
          if (p) { v.nickname = p.nickname || v.nickname; v.avatarUri = p.profilePictureUri ?? v.avatarUri; }
        }
      } catch { /* Snapshot genügt */ }
      cur.current = { cursor: r.nextCursor, done: r.nextCursor === "" };
      setCursor(r.nextCursor); setDone(cur.current.done); setFailed(false);
      setItems((old) => {
        const ids = new Set(old.map((o) => o.id));
        return [...old, ...views.filter((v) => !ids.has(v.id))];
      });
    } catch { setFailed(true); }
    finally { busy.current = false; setLoading(false); }
  }, []);

  useEffect(() => {
    loadMore();
    const onAdded = (e: JoinEntry) => {
      const v = toView(e);
      setItems((old) => (old.some((o) => o.id === v.id) ? old : [v, ...old]));
    };
    impServiceClient.on(ImpServiceClientEvent.JoinAdded, onAdded);
    return () => { impServiceClient.off(ImpServiceClientEvent.JoinAdded, onAdded); };
  }, [loadMore]);

  return { items, done, loading, failed, loadMore, hasMore: cursor !== "" || !done };
}
