import { CommunityUserOnlineStatus as S } from "@rootsdk/client-app";

/** Online = Community geöffnet (aktiv/abwesend) oder – für Freunde sichtbar – online/abwesend anderswo. */
export function isOnline(status: S): boolean {
  return status === S.OnlineAndAttached || status === S.AwayAndAttached || status === S.Online || status === S.Away;
}

export function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

export function formatDate(ms: number): string {
  return new Date(ms).toLocaleDateString("de-CH", { day: "2-digit", month: "2-digit", year: "numeric" });
}
export function formatTime(ms: number): string {
  return new Date(ms).toLocaleTimeString("de-CH", { hour: "2-digit", minute: "2-digit" });
}
