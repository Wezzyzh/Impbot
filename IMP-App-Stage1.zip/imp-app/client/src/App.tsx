import React, { useEffect, useState } from "react";
import { A } from "./assets";
import { Stars } from "./Stars";
import { Welcome } from "./Welcome";
import { useViewer } from "./hooks";
import "./styles.css";

type TabId = "welcome" | "mod" | "support";

const Placeholder: React.FC<{ icon: string; title: string }> = ({ icon, title }) => (
  <section className="panel placeholder">
    <div className="tile tile--lg"><img src={icon} alt="" width={64} height={64} /></div>
    <h2 className="h2">{title}</h2>
    <p>Kommt in der nächsten Etappe</p>
  </section>
);

const App: React.FC = () => {
  const viewer = useViewer();
  const isStaff = viewer?.isStaff === true; // nur Anzeige; echte Prüfung passiert serverseitig
  const [tab, setTab] = useState<TabId>("welcome");
  useEffect(() => { if (tab === "mod" && !isStaff) setTab("welcome"); }, [tab, isStaff]);

  const tabs: { id: TabId; label: string; icon: string }[] = [
    { id: "welcome", label: "Welcome", icon: A.welcome },
    ...(isStaff ? [{ id: "mod" as TabId, label: "Chat Moderation", icon: A.shield }] : []),
    { id: "support", label: "Support", icon: A.support },
  ];

  return (
    <div className="app">
      <Stars />
      <div className="wrap">
        <header className="top">
          <img className="top__logo" src={A.logo} alt="IMP" width={44} height={44} />
          <nav className="tabs" role="tablist" aria-label="Bereiche">
            {tabs.map((t) => (
              <button key={t.id} role="tab" aria-selected={tab === t.id} className={`tab${tab === t.id ? " tab--on" : ""}`} onClick={() => setTab(t.id)}>
                <img src={t.icon} alt="" width={24} height={24} /><span>{t.label}</span>
              </button>
            ))}
          </nav>
        </header>
        <main key={tab} className="view">
          {tab === "welcome" && <Welcome viewer={viewer} />}
          {tab === "mod" && isStaff && <Placeholder icon={A.shield} title="Chat Moderation" />}
          {tab === "support" && <Placeholder icon={A.support} title="Support" />}
        </main>
      </div>
    </div>
  );
};
export default App;
